#### SIMULATIONS ####

The file ss_setting_master_121022.R will reproduce all simulation results in the paper. The user must first set the setting e.g. 

setting = 1

and then can run the code in ss_setting_master_121022.R. Commenting differentiates between the main results, empirical power, comparison results, and estimated power. All results for all settings (1,2,3,4) match the results shown in the paper.

#### EXAMPLE ####

The file tonic_ss_reproducible.R will reproduce example results in the paper. You must have your own access to the TONIC data via the NIDDK data repository.