library(sas7bdat)
library(devtools)
tonic.data.2 = read.sas7bdat("table2.sas7bdat")
tonic.data = read.sas7bdat("table3.sas7bdat")
tonic.data = tonic.data[,-2]

tonic.data.new = merge(tonic.data.2, tonic.data, by = "ID")
tonic.data.new = tonic.data.new[!is.na( tonic.data.new$CALT96) & !is.na(tonic.data.new$DNAS),]
s1 = -1*tonic.data.new$CALT96[tonic.data.new$TX == "1Vit"]
s0 = -1*tonic.data.new$CALT96[tonic.data.new$TX == "3Plb"]

y1 = -1*tonic.data.new$DNAS[tonic.data.new$TX == "1Vit"]
y0 = -1*tonic.data.new$DNAS[tonic.data.new$TX == "3Plb"]

length(y1)
length(y0)

#run package functions only
devtools::install_github("laylaparast/SurrogateRank")
library(SurrogateRank)
test.surrogate(yone=y1, yzero=y0, sone = s1, szero=s0,power.want.s = 0.7)


test.surrogate(yone=y1, yzero=y0, sone = s1, szero=s0,power.want.s = 0.3)

