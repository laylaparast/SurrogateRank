
library(quantreg)
library(Rsurrogate)
library(devtools)
install_github("celehs/OptimalSurrogate")
library(OptimalSurrogate)

n1=25
n0=25

gen.data = function(setting.set,n1,n0){
	#useless surrogate, all zero, y1 and y0 too different, changed so maybe will be better
	if(setting.set==1){
		s1 = rnorm(n1,2/3,1)
		s0 = rnorm(n0, 2/3,1)
		y1 = rnorm(n1, 5, sqrt(3))
		y0 = rnorm(n0, 3, sqrt(3))
	
	}
	#perfect surrogate, added error to y because too crazy, robust not doing well
	if(setting.set==2){
		y1 = rnorm(n1, 6, sqrt(3))
		y0 = rnorm(n0, 2.5, sqrt(3))
		s1 = y1 + rnorm(n1, 0, sqrt(0.1))
		s0 = y0 + rnorm(n0, 0, sqrt(0.1))
	
	}
	#not perfect, more variance
	if(setting.set==3){
		s1 = rnorm(n1, 5, sqrt(3))
		s0 = rnorm(n0, 3, sqrt(3))
		y1 = rnorm(n1, 1.5+s1, sqrt(0.6))
		y0 = rnorm(n0, 0+s0, sqrt(0.6))
	}
	#not perfect and mis-specified, wrong direction for delta
	if(setting.set==4){
		s1 = exp(rnorm(n1, 2.5, 1.5))
		s0 = exp(rnorm(n0, 0.5, 1.5))
		y1 = 2.0 + 1.2*sqrt(s1) + 0.3*exp(s1/5) + exp(rnorm(n1, 0, sqrt(0.3)))
		y0 = 0.8*sqrt(s0) + 0.2*exp(s0/5) + exp(rnorm(n0, 0, sqrt(0.3)))
	}

	return(list("y1"=y1, "y0" = y0, "s1" =s1,"s0"=s0))
}

calc.truth = function(setting.set) {
	if(setting.set==1){
		uy = 1- pnorm(0,5-3,sd = sqrt(3+3))
		us = 1-pnorm(0,0,sd = sqrt(2))
		rho = NA
	}
	if(setting.set==2){
		dd = gen.data(setting.set=2,n1=10000,n0=10000)
		uy = (10000*10000)^(-1)*wilcox.test(dd$y1,dd$y0)$statistic
		us = (10000*10000)^(-1)*wilcox.test(dd$s1,dd$s0)$statistic
		rho = cor(dd$y0,dd$s0, method = "spearman")
	}
	if(setting.set==3){
		dd = gen.data(setting.set=3,n1=10000,n0=10000)
		uy = (10000*10000)^(-1)*wilcox.test(dd$y1,dd$y0)$statistic
		us = (10000*10000)^(-1)*wilcox.test(dd$s1,dd$s0)$statistic
		rho = cor(dd$y0,dd$s0, method = "spearman")
	}
	if(setting.set==4){
		dd = gen.data(setting.set=4,n1=10000,n0=10000)
		uy = (10000*10000)^(-1)*wilcox.test(dd$y1,dd$y0)$statistic
		us = (10000*10000)^(-1)*wilcox.test(dd$s1,dd$s0)$statistic
		rho = cor(dd$y0,dd$s0, method = "spearman")
	}
	if(setting.set==5){
		dd = gen.data(setting.set=5,n1=10000,n0=10000)
		uy = (10000*10000)^(-1)*wilcox.test(dd$y1,dd$y0)$statistic
		us = (10000*10000)^(-1)*wilcox.test(dd$s1,dd$s0)$statistic
		rho = cor(dd$y0,dd$s0, method = "spearman")
	}
	if(setting.set==6){
		dd = gen.data(setting.set=6,n1=10000,n0=10000)
		uy = (10000*10000)^(-1)*wilcox.test(dd$y1,dd$y0)$statistic
		us = (10000*10000)^(-1)*wilcox.test(dd$s1,dd$s0)$statistic
		rho = cor(dd$y0,dd$s0, method = "spearman")
	}

	delta = uy-us
	return(list("uy"=uy, "us" = us, "delta" =delta, "rho" = rho))
}

#a is one number, b is vector
var.wil = function(a, b, flip = FALSE){
	if(!flip) return(mean(sapply(b, my.wilcox, x= a)))
	if(flip) return(mean(sapply(b, my.wilcox, y= a)))
}


delta.calculate = function( full.data= NULL,yone= NULL,yzero= NULL,sone= NULL,szero= NULL) {
	if(!is.null(full.data)){
		yone=full.data[full.data[,3]==1,1]
		yzero=full.data[full.data[,3]==0,1]
		sone = full.data[full.data[,3]==1,2]
		szero=full.data[full.data[,3]==0,2]	
	}
	test.y = wilcox.test(yone,yzero, exact=F)
	test.s = wilcox.test(sone,szero, exact = F)
	n1.f = length(yone)
	n0.f = length(yzero)
	u.y = (n1.f*n0.f)^(-1)*test.y$statistic
	u.s = (n1.f*n0.f)^(-1)*test.s$statistic
	delta.estimate = u.y-u.s
	
	#variance, X is treated, Y is control, n is size of control, m is size of treatment
	#need to calculate S_01 and S_10
	#S_10
	#1,1 ELEMENT	
	m.count = length(yone)
	n.count = length(yzero)
	#need V10.Xi.Y
	V10.Xi.Y = sapply(yone, var.wil, b = yzero)
	V10.Xi.S = sapply(sone, var.wil, b = szero)
	V01.Yj.Y = sapply(yzero, var.wil, b = yone, flip = TRUE)
	V01.Yj.S = sapply(szero, var.wil, b = sone, flip = TRUE)
	
	
	s10.11.YY = 1/(m.count-1)*sum((V10.Xi.Y-u.y)*(V10.Xi.Y-u.y))
	s10.12.YS = 1/(m.count-1)*sum((V10.Xi.Y-u.y)*(V10.Xi.S-u.s))
	s10.22.SS =  1/(m.count-1)*sum((V10.Xi.S-u.s)*(V10.Xi.S-u.s))
	s10.21.SY =  1/(m.count-1)*sum((V10.Xi.Y-u.y)*(V10.Xi.S-u.s))
	
	s01.11.YY = 1/(n.count-1)*sum((V01.Yj.Y-u.y)*(V01.Yj.Y-u.y))
	s01.12.YS = 1/(n.count-1)*sum((V01.Yj.Y-u.y)*(V01.Yj.S-u.s))
	s01.22.SS = 1/(n.count-1)*sum((V01.Yj.S-u.s)*(V01.Yj.S-u.s))
	s01.21.SY =1/(n.count-1)*sum((V01.Yj.Y-u.y)*(V01.Yj.S-u.s))
	
	S10 = matrix(c(s10.11.YY, s10.12.YS,s10.21.SY,s10.22.SS), nrow=2, ncol = 2, byrow=TRUE)
	S01 = matrix(c(s01.11.YY, s01.12.YS,s01.21.SY,s01.22.SS), nrow=2, ncol = 2, byrow=TRUE)
	S.mat = (1/m.count)*S10 + (1/n.count)*S01
	sd.y = sqrt(S.mat[1,1])
	sd.s = sqrt(S.mat[2,2])
	L = t(as.matrix(c(1,-1)))

	sd.est = (L%*%((1/m.count)*S10 + (1/n.count)*S01)%*%t(L))^(1/2)
	
	return(list("u.y" = u.y,"u.s" = u.s, "delta.estimate" = delta.estimate, "sd.u.y" = sd.y, "sd.u.s" = sd.s, "sd.delta" = sd.est))
}


#in delong paper x = a, y = b
my.wilcox = function(x,y) {
	if(x>y) return(1)
	if(x==y) return(1/2)
	if(x<y) return(0)
}

my.wilcox.2 = function(treat,control) {
	kk = 0
	for(j in 1:length(treat)) {
		for(i in 1:length(control)){
			kk = kk + my.wilcox(treat[j], control[i])
		}
	}
	return(kk)
}

#value is epsilon, in order to reject, the entire CI has to be below value
check.in = function(value, rr) {
	if(rr[1] < value & rr[2] < value) return(1)
	else return(0)
}

cov.check = function(value, rr) {
	if(rr[1] <= value & rr[2] >= value) return(1)
	else return(0)
}

#ci.uy = vector = (lower bound of CI for delta, upper bound of CI for delta, estimated uy); us.star = us*
check.in.eps = function(ci.uy, us.star) {
	eps = max(0, ci.uy[3] - us.star)
	if(ci.uy[2] < eps) return(1)
	else return(0)
}


set.seed(100)

NUM = 1000
main.result = matrix(nrow = NUM, ncol = 6)
comp.result = matrix(nrow = NUM, ncol = 4)

#first is estimate of delta, second is lower bound of CI, third is higher bound of CI

do.comps = TRUE
for(kk in 1:NUM) {
dat = gen.data(setting.set=setting, n1=n1, n=n0)
y1 = dat$y1
y0 = dat$y0
s1 = dat$s1
s0 = dat$s0

dd = delta.calculate(yone=y1, yzero=y0, sone = s1, szero=s0)
delta.estimate = dd$delta.estimate
u.y = dd$u.y
u.s = dd$u.s

main.result[kk,1] = u.y
main.result[kk,2] = u.s
main.result[kk,3] = delta.estimate
main.result[kk,4] = dd$sd.u.y
main.result[kk,5] = dd$sd.u.s
main.result[kk,6] = dd$sd.delta

if(do.comps) {
	#freedman
	R.f = try(R.s.estimate(sone = s1, szero=s0, yone=y1, yzero=y0, var = FALSE,  number = "single", type = "freedman"))
	if(is.list(R.f)) {
	comp.result[kk,1] = R.f$R.s }
	
	#model-based, flexible
	R.m = try(R.s.estimate(sone = s1, szero=s0, yone=y1, yzero=y0, var = FALSE , number = "single", type = "model"))
	if(is.list(R.m)){
	comp.result[kk,2] = R.m$R.s
	}
	
	#robust
	R.r = try(R.s.estimate(sone = s1, szero=s0, yone=y1, yzero=y0, var = FALSE,  number = "single", type = "robust"))
	if(is.list(R.r)) {
		comp.result[kk,3] = R.r$R.s}
	
	#Xuan, optimal transformation
	dat.opt = cbind(c(y1,y0), c(s1,s0), c(rep(1,length(y1)), rep(0,length(y0))))
	R.opt = try(pte_cont(sob = dat.opt[,2], yob = dat.opt[,1], aob = dat.opt[,3])[[1]])
	if(is.matrix(R.opt)){
		comp.result[kk,4] = R.opt[3,1]}
  
}

print(kk)
}

#########################################
### MAIN RESULTS
#########################################

main.result = as.data.frame(main.result)
names(main.result) = c("u.y", "u.s","delta", "sd.y","sd.s","sd.delta")
write.table(main.result, paste("results_setting", setting,"_121022.txt",sep=""), quote = F, row.names=F)
write.table(comp.result, paste("comp_results_setting", setting,"_121022.txt",sep=""), quote = F, row.names=F)
#main.result.setting1 = main.result

###table
main.result.setting1 = read.table(paste("results_setting", setting,"_121022.txt",sep=""), header = T)
comp.result.setting1 = read.table(paste("comp_results_setting", setting,"_121022.txt",sep=""), header = T)
set.seed(100)
tr =  calc.truth(setting)

m1 = apply(main.result.setting1,2,mean)
sd1 = apply(main.result.setting1,2,sd)
z.alpha = qnorm(0.95)
ci.uy = cbind(-1, main.result.setting1[,1] + z.alpha* main.result.setting1[,4])
ci.us = cbind(-1, main.result.setting1[,2] + z.alpha* main.result.setting1[,5])
ci.delta = cbind(-1, main.result.setting1[,3] + z.alpha* main.result.setting1[,6])
cov = c(mean(apply(ci.uy,1,cov.check, value = tr$uy)),
mean(apply(ci.us,1,cov.check, value = tr$us)),
mean(apply(ci.delta,1,cov.check, value = tr$delta)))

#########################################
### EMPIRICAL POWER
#########################################

#what % of iterations is the whole CI below the value
##power
power.want = 0.80
sd.null = sqrt((n1+n0+1)/(12*n1*n0))
z.alpha.2 = qnorm(0.975)
u.s.power = 1/2-(qnorm(1-power.want)-z.alpha.2)*(sd.null)

pow = mean(apply(cbind(ci.delta, main.result.setting1[,1]),1,check.in.eps, us.star = u.s.power))
pow


tab = round(rbind(c(tr$uy, tr$us, tr$delta), 
c(m1[1], m1[2], m1[3]),c(tr$uy, tr$us, tr$delta) - c(m1[1], m1[2], m1[3]), c(sd1[1], sd1[2], sd1[3]), c(m1[4:6]),cov),3)
row.names(tab) = c("Truth", "Estimate","Bias", "ESE","ASE","Coverage")
tab
latex.table(tab, paste("table_setting",setting,"121022.tex", sep=""), row.names = T, col.names = F, caption = "", dcolumn = T)


#########################################
### COMPARISONS
#########################################

p.tab = rbind(c("Freedman","Model", "Robust", "Optimal"),round(c(mean(comp.result.setting1[,1]), mean(comp.result.setting1[,2]), mean(comp.result.setting1[,3]), mean(comp.result.setting1[,4])),3),
round(c(min(comp.result.setting1[,1]), min(comp.result.setting1[,2]), min(comp.result.setting1[,3]), min(comp.result.setting1[,4])),3),
round(c(max(comp.result.setting1[,1]), max(comp.result.setting1[,2]), max(comp.result.setting1[,3]), max(comp.result.setting1[,4])),3))

#if nas
p.tab = rbind(c("Freedman","Model", "Robust", "Optimal"),round(c(mean(comp.result.setting1[,1], na.rm = T), mean(comp.result.setting1[,2], na.rm = T), mean(comp.result.setting1[,3], na.rm = T), mean(comp.result.setting1[,4], na.rm = T)),3),
round(c(min(comp.result.setting1[,1], na.rm = T), min(comp.result.setting1[,2], na.rm = T), min(comp.result.setting1[,3], na.rm = T), min(comp.result.setting1[,4], na.rm = T)),3),
round(c(max(comp.result.setting1[,1], na.rm = T), max(comp.result.setting1[,2], na.rm = T), max(comp.result.setting1[,3], na.rm = T), max(comp.result.setting1[,4], na.rm = T)),3))


p.tab
row.names(p.tab) = c("method","Mean", "Minimum","Maximum")

latex.table(p.tab, paste("comptable_setting",setting,"121022.tex", sep=""), row.names = F, col.names = F, caption = "", dcolumn = T)


#########################################
### ESTIMATED POWER
#########################################

#assume a rank correlation of rho, sing rank correlation from real data generation - in control group

n.star=25
n=n.star*2
z.alpha = qnorm(0.95)
power.want = 0.80
sd.null = sqrt((n+1)/(3*n^2))
z.alpha.2 = qnorm(0.975)
us.est = 1/2-(qnorm(1-power.want)-z.alpha.2)*(sd.null)


set.seed(100)
tr =  calc.truth(setting)
rho = tr$rho
rho
delta.se.est = sqrt(2*(1-rho)/(3*n))

est.power = pnorm((1/delta.se.est)*(tr$uy - us.est-tr$delta) - z.alpha)
est.power

#assume a rank correlation of rho = 0.60

rho = 0.6
delta.se.est = sqrt(2*(1-rho)/(3*n))

est.power = pnorm((1/delta.se.est)*(tr$uy - us.est-tr$delta) - z.alpha)
est.power


#assume a rank correlation of rho = 0.95

rho = 0.95
delta.se.est = sqrt(2*(1-rho)/(3*n))

est.power = pnorm((1/delta.se.est)*(tr$uy - us.est-tr$delta) - z.alpha)
est.power

